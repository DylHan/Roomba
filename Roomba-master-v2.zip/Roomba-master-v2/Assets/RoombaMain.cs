﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class RoombaMain : MonoBehaviour
{
    private Transform myTransform;
    public float walkSpeed = 5.0f;
    public float countNumber = 0.0f;
    public Text counterText;
    public Text timerText;
    public Text winText;
    public Text loseText;
    public Image countdownClock;
    public float timer = 30.0f;
    public float numberTimer = 30.0f;
    public bool timesUp;
    public GameObject winPanel;
    public GameObject losePanel;

    void Start()
    {
        myTransform = this.transform;
        counterText.text = "0";
        winText.text = "";
        loseText.text = "";
        timesUp = false;
    }

    void Update()
    {
        Controls();
        if (timesUp == false)
        {
            Timers();
        }
        if (countNumber == 4)
        {
            winPanel.transform.localScale = new Vector3(1, 1, 1);
            winText.text = "You Win!!!";
            timesUp = true;
        }
    }

    void Controls()
    {
        //Move Up
        if (Input.GetKey("w"))
        {
            myTransform.Translate(walkSpeed * Vector3.forward);
        }

        //Move Left
        if (Input.GetKey("a"))
        {
            myTransform.Translate(walkSpeed * Vector3.left);
        }
        //Move Down
        if (Input.GetKey("s"))
        {
            myTransform.Translate(walkSpeed * Vector3.back);
        }

        //Move Right
        if (Input.GetKey("d"))
        {
            myTransform.Translate(walkSpeed * Vector3.right);
        }

    }

    void Timers()
    {
            counterText.text = "" + countNumber;
            countdownClock.fillAmount -= 1.0f / timer * Time.deltaTime;
            numberTimer -= Time.deltaTime;
            timerText.text = "" + Mathf.Round(numberTimer);

        if (numberTimer <= 0)
        {
            losePanel.transform.localScale = new Vector3(1, 1, 1);
            loseText.text = "You Lose....";
            timesUp = true;
        }
    }


    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Number"))
        {
            other.gameObject.SetActive(false);
            countNumber += 1;
        }
    }



}